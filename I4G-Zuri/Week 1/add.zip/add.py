var1 = 8
var2 = 6
print (var1 + var2)
